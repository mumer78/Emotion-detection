from flask import Flask, render_template, request, jsonify
import cv2
import numpy as np
from tensorflow.keras.models import load_model
import base64

app = Flask(__name__)

# Load your trained model
model = load_model("C:/Users/LENOVO/Desktop/ai project/emotion_model_save.keras")
emotion_map = {0: "angry", 1: "happy", 2: "neutral", 3: "sad", 4: "surprise"}

# Load OpenCV face detector
face_detector = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

def predict_emotion(frame):
    """Detect faces and predict emotions on a single frame"""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_detector.detectMultiScale(gray, 1.3, 5)
    results = []

    for (x, y, w, h) in faces:
        face_region = gray[y:y+h, x:x+w]
        face_region = cv2.resize(face_region, (48, 48))
        face_region = face_region.astype("float32") / 255.0
        face_region = np.expand_dims(face_region, axis=0)
        face_region = np.expand_dims(face_region, axis=-1)

        pred = model.predict(face_region, verbose=0)[0]
        max_idx = int(np.argmax(pred))
        emotion = emotion_map[max_idx]

        results.append({
            "box": [int(x), int(y), int(w), int(h)],
            "emotion": emotion,
            "scores": {emo: float(score) for emo, score in zip(emotion_map.values(), pred)}
        })

    return results

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    if 'image' not in data:
        return jsonify([])

    # Convert base64 image to numpy array
    img_data = data['image'].split(",")[1]
    nparr = np.frombuffer(base64.b64decode(img_data), np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    predictions = predict_emotion(img)
    return jsonify(predictions)

if __name__ == '__main__':
    app.run(debug=True)
